CREATE TABLE EMP
(id_empregado number CONSTRAINT emp_pk primary key,
nome varchar(50) not null,
salario number(10,2) CONSTRAINT emp_sal_ck check (salario > 0),
email varchar(100) CONSTRAINT emp_email_uk UNIQUE,
deptno number(2));

insert into emp
values (1,'Z�',1000,'a@a',null);

drop table emp;

CREATE TABLE DEPT
(deptno number(2) constraint dept_pk primary key,
dname varchar(14) CONSTRAINT dept_dname_nn not null,
loc varchar(13) not null,
create_date date);

alter table emp
add
CONSTRAINT emp_dept_fk
FOREIGN key(dept_no)
references dept(deptno);

CREATE TABLE EMP
(id_empregado number       CONSTRAINT emp_pk       primary key,
nome          varchar(50)  not null,
salario       number(10,2) CONSTRAINT emp_sal_ck   check (salario > 0),
email         varchar(80)  CONSTRAINT emp_email_uk UNIQUE,
deptno        number(2)    CONSTRAINT dept_emp_fk  REFERENCES dept);