---------------------------------------------------------------------

create table EMPRESTIMOS(
cod_emprestimo integer      CONSTRAINT EMPRESTIMO_PK PRIMARY KEY,
dt_retirada    date         NOT NULL,
dt_entrega     date,
cod_aluno      number(5),
cod_livros     integer
);

---------------------------------------------------------------------

create table ALUNOS(
cod_aluno number(5)         CONSTRAINT ALUNOS_PK PRIMARY KEY,
nome      varchar2(20)      NOT NULL,
sobrenome varchar2(20)      NOT NULL,
dt_nasc   date              NOT NULL
);

---------------------------------------------------------------------

create table LIVROS(
cod_livros integer          CONSTRAINT LIVROS_PK PRIMARY KEY,
titulo     varchar(100)     NOT NULL
);

---------------------------------------------------------------------

create table LIVROS_AUTORES(
cod_autor  integer references autores,
cod_livros integer references livros,
CONSTRAINT LIVROS_AUTORES_PK PRIMARY KEY(cod_livros, cod_autor)
);

drop table LIVROS_AUTORES;

---------------------------------------------------------------------

create table AUTORES(
cod_autor integer          CONSTRAINT  AUTORES_PK PRIMARY KEY,
nome      varchar2(50)     NOT NULL,
sobrenome varchar2(50)     NOT NULL
);

---------------------------------------------------------------------


alter table    EMPRESTIMOS
add CONSTRAINT EMPRESTIMO_ALUNOS_FK
FOREIGN KEY    (cod_aluno)
references     ALUNOS;

---------------------------------------------------------------------

alter table    EMPRESTIMOS
add CONSTRAINT EMPRESTIMO_LIVROS_FK
foreign key    (cod_livros)
references     LIVROS;

---------------------------------------------------------------------

alter table    LIVROS_AUTORES
add CONSTRAINT AUTORES_FK 
foreign key    (cod_autor)
references     AUTORES;

---------------------------------------------------------------------

alter table    LIVROS_AUTORES
add CONSTRAINT LIVROS_FK
foreign key    (cod_livros)
references     LIVROS;

---------------------------------------------------------------------
 
